-****-Social network manager-****-
Utilização:

java -jar Social_Network_Manager -opção (nome do ficheiro da rede de nós) (nome do ficheiro da rede de ramos)


Opções:

-t		Insere vários cálculos num ficheiro de texto.

-k		Quando executado juntamente com -t e um número inteiro, junta ao ficheiro o cálculo da matriz potencia do grau do número.

-n		Abre um menu para escolher os cálculos.
