package social_network_manager;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author isaac
 */
public class Config {
    public static final int N_CAMPOS_INFO=5;
    public static final int N_CAMPOS_RELACOES=3;
    public static final int N_MAX_NOS=200;
    public static final int N_MAX_RAMOS=600;
    public static final int POSICAO_ID_FROM=0;
    public static final int POSICAO_ID_TO=1;
    public static final int POSICAO_ID_NOS=0;
    public static final int POSICAO_WEBSITE=4;
    public static final String SEPARADOR_DADOS=",";
    public static final int LENGTH_VETOR_PAGERANK=1;
    public static final int POS_PAGERANK=0;
}
