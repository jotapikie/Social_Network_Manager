/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package social_network_manager;

import org.la4j.Matrix;
import org.la4j.matrix.dense.Basic2DMatrix;
import org.la4j.decomposition.EigenDecompositor;

/**
 *
 * @author isaac
 */
public class CalculosMatrizes {

    public static float calcularDensidade(double[][] Matriz, int nrRamos) {
        int nrMaxRamos = ((int) Math.pow(Matriz.length, 2) - Matriz.length);
        return (float) nrRamos / nrMaxRamos;
    }

    /**
     *
     * @param ramos
     * @return
     */
    public static float calcularGrauMedio(double[][] ramos) {
        int somaNos = 0;
        for (int i = 0; i < ramos.length; i++) {
            somaNos += calcularGrauNo(ramos, i);
        }

        return (float) somaNos / ramos.length;
    }

    public static int eliminarValoresPropriosRepetidos(double[] valProprios, double[] valPropriosSemRepetidos) {
        int nValProprios = 0;

        for (int i = 0; i < valProprios.length; i++) {
            boolean repetido = false;
            if (valProprios[i] > -0.001 && valProprios[i] < 0.001) {
                valProprios[i] = 0;
            }
            for (int j = 0; j < nValProprios; j++) {
                if (valProprios[i] == valPropriosSemRepetidos[j]) {
                    repetido = true;

                }
            }
            if (!repetido) {
                valPropriosSemRepetidos[nValProprios] = valProprios[i];
                nValProprios++;
            }
        }
        return nValProprios;
    }

    public static double[] calcularValoresProprios(double[][] ramos) {

        Matrix adjacencias = new Basic2DMatrix(ramos);

        EigenDecompositor eigenD = new EigenDecompositor(adjacencias);

        Matrix[] matrizPropria = eigenD.decompose();

        double matValProprio[][] = matrizPropria[1].toDenseMatrix().toArray();

        double[] valoresProprios = new double[ramos.length];
        for (int i = 0; i < ramos.length; i++) {
            valoresProprios[i] = matValProprio[i][i];
        }
        return valoresProprios;
    }

    public static int calcularGrauNo(double[][] ramos, int posicaoID) {
        int grauNo = 0;

        for (int coluna = 0; coluna < ramos.length; coluna++) {

            if (ramos[posicaoID][coluna] != 0) {
                grauNo++;
            }
        }

        return grauNo;
    }

    public static int calcularGrauSaida(double[][] ramos, int posicaoID) {
        int grauSaida = 0;

        for (int coluna = 0; coluna < ramos.length; coluna++) {

            if (ramos[posicaoID][coluna] != 0) {
                grauSaida++;
            }
        }

        return grauSaida;
    }

    public static int calcularGrauEntrada(double[][] ramos, int posicaoID) {
        int grauEntrada = 0;

        for (int linha = 0; linha < ramos[0].length; linha++) {

            if (ramos[linha][posicaoID] != 0) {
                grauEntrada++;
            }
        }

        return grauEntrada;
    }

    public static double[][] calcularVetoresProprios(double[][] ramos) {

        Matrix adjacencias = new Basic2DMatrix(ramos);

        EigenDecompositor eigenD = new EigenDecompositor(adjacencias);

        Matrix[] matrizPropria = eigenD.decompose();

        return matrizPropria[0].toDenseMatrix().toArray();
    }

    public static double calcMaxValProprio(double[][] ramos) {
        double[] valProprios = calcularValoresProprios(ramos);
        double maiorValProprio = valProprios[0];
        for (int i = 1; i < valProprios.length; i++) {
            if (valProprios[i] > maiorValProprio) {
                maiorValProprio = valProprios[i];
            }
        }
        return maiorValProprio;
    }

    public static double[][] potenciaMatrizAdjacencias(double[][] ramos, int grau) {
        double[][] resultado = ramos;
        for (int nGrau = 1; nGrau < grau; nGrau++) {
            resultado = multiplicarMatrizes(resultado, ramos);
        }

        return resultado;
    }

    public static double[][] multiplicarMatrizes(double[][] a, double[][] b) {
        double[][] resultado = new double[a.length][b[0].length];
        for (int i = 0; i < a.length; i++) {
            for (int j = 0; j < b[i].length; j++) {
                for (int k = 0; k < b.length; k++) {
                    resultado[i][j] += a[i][k] * b[k][j];
                }
            }
        }
        return resultado;
    }

    public static double calcCentralidadeVetorProprio(double[][] matAdjacencias) {

        Matrix adjacencias = new Basic2DMatrix(matAdjacencias);

        EigenDecompositor eigenD = new EigenDecompositor(adjacencias);

        Matrix[] matrizPropria = eigenD.decompose();

        double matVecProprio[][] = matrizPropria[0].toDenseMatrix().toArray();
        double matValProprio[][] = matrizPropria[1].toDenseMatrix().toArray();

        int posMaiorValProprio = 0;
        double maiorValProprio = matValProprio[0][0];

        for (int i = 1; i < matValProprio.length; i++) {
            if (matValProprio[i][i] > maiorValProprio) {
                maiorValProprio = matValProprio[i][i];
                posMaiorValProprio = i;
            }
        }
        double centralidade = matVecProprio[0][posMaiorValProprio];
        for (int i = 1; i < matVecProprio.length; i++) {
            if (matVecProprio[i][posMaiorValProprio] > centralidade) {
                centralidade = matVecProprio[i][posMaiorValProprio];
            }
        }

        return centralidade;
    }

    public static double[][] criarMatrizMPageRank(double[][] matrizA, double dampingFactor) {
        double[][] matrizM = new double[matrizA.length][matrizA[0].length];
        for (int i = 0; i < matrizA.length; i++) {
            for (int j = 0; j < matrizA[i].length; j++) {
                matrizM[i][j] = (dampingFactor * matrizA[i][j]) + (1 - dampingFactor) / matrizA.length;
            }
        }
        return matrizM;
    }

    public static double[][] calcPageRank(double[][] matriz, double dampingFactor, int nIteracoes) {
        double[][] matrizA = criarMatrizAPageRank(matriz);
        double[][] matrizM = criarMatrizMPageRank(matrizA, dampingFactor);
        double[][] pageRank = new double[matriz.length][Config.LENGTH_VETOR_PAGERANK];
        
        for (int i = 0; i < matrizA.length; i++) {
            for (int j = 0; j < matrizA.length; j++) {
                System.out.print(matrizM[i][j]+" ");
            }
            System.out.println("");
        }
        for (int i = 0; i < pageRank.length; i++) {
            pageRank[i][Config.POS_PAGERANK] = 1;
        }
        for (int i = 0; i < nIteracoes; i++) {
            pageRank = multiplicarMatrizes(matrizM, pageRank);
        }
        return pageRank;
    }

    public static double[][] calcPageRankMetodoVetor(double[][] matriz, double dampingFactor) {
        double[][] matrizA = criarMatrizAPageRank(matriz);
        double[][] matrizM = criarMatrizMPageRank(matrizA, dampingFactor);

        Matrix matrixM = new Basic2DMatrix(matrizM);

        EigenDecompositor eigenD = new EigenDecompositor(matrixM);

        Matrix[] matrizPropria = eigenD.decompose();

        double matVecProprio[][] = matrizPropria[0].toDenseMatrix().toArray();
        double matValProprio[][] = matrizPropria[1].toDenseMatrix().toArray();

        int posMaiorValProprio = 0;
        double maiorValProprio = matValProprio[0][0];

        for (int i = 1; i < matValProprio.length; i++) {
            if (matValProprio[i][i] > maiorValProprio) {
                maiorValProprio = matValProprio[i][i];
                posMaiorValProprio = i;
            }
        }

        double[][] pageRank = new double[matrizM.length][1];
        for (int i = 1; i < matVecProprio.length; i++) {
            pageRank[i][0] = matVecProprio[i][posMaiorValProprio];
        }
        return pageRank;
    }

    public static double[][] criarMatrizAPageRank(double[][] matriz) {
        double[][] MatrizA = new double[matriz.length][matriz.length];

        for (int i = 0; i < matriz.length; i++) {
            for (int j = 0; j < matriz[i].length; j++) {

                if (i == j) {
                    MatrizA[i][j] = 0;
                } else if (matriz[i][j] == 1) {

                    MatrizA[i][j] = (1.0 / calcularGrauSaida(matriz, i));

                } else if (calcularGrauSaida(matriz, i) == 0) {
                    MatrizA[i][j] = (1.0 / (matriz.length));

                } else{
                    MatrizA[i][j]=0;
                }

            }
        }
        return MatrizA;

    }
}
