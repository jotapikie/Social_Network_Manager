/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package social_network_manager;


/**
 *
 * @author isaac
 */
public class Utilitarios {

    /**
     * Retorna a linha onde o elemento se encontra ou se não encontrar o elemento
     * retorna -1
     *
     * @param infoRelacoes
     * @param id
     * @param nNos
     * @return
     */
    public static int procurarString(String[][] infoRelacoes, String id, int nNos) {

        for (int i = 0; i < nNos; i++) {
            if (infoRelacoes[i][0].equals(id)) {
                return i;
            }

        }
        return -1;

    }

    public static int procurarDouble(double[][] infoRelacoes, String id) {

        for (int i = 0; i < infoRelacoes.length; i++) {
            if (infoRelacoes[i][0] == Double.parseDouble(id)) {
                return i;
            }

        }
        return -1;

    }

     public static void mostrarMatrizS(String[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.printf("%15s", m[i][j]);
            }
            System.out.println();
        }
    }
     
    public static void mostrarMatrizD(double[][] m) {
        for (int i = 0; i < m.length; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.printf("%15f", m[i][j]);
            }
            System.out.println();
        }
    } 
     public static void mostrarPrimeirasLinhasMatrizS(String[][] m, int linhas) {
        for (int i = 0; i < linhas; i++) {
            for (int j = 0; j < m[i].length; j++) {
                System.out.printf("%15s", m[i][j]);
            }
            System.out.println();
        }
        
    }

}
