/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package social_network_manager;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 *
 * @author isaac
 */
public class LeitorFicheiros {

    public static int lerMatriz(String nomeFich, int nCamposInfo, String[][] matriz, int maxValue) throws FileNotFoundException {

        if (new File(nomeFich).exists()) {
            int pos=0;
            try (Scanner fInput = new Scanner(new File(nomeFich))) {
            
                while (fInput.hasNextLine()) {
                    String linha = fInput.nextLine();
                   
                    if ((linha.trim()).length() > 0 && pos < maxValue) {
                        String[] temp = linha.split(Config.SEPARADOR_DADOS);
                        for (int i = 0; i < temp.length; i++) {
                            matriz[pos][i] = temp[i];
                        }
                        pos++;
                    }
                }
            }
            return pos;
        }
        return 0;

    }
}
