/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package social_network_manager;

import java.awt.Desktop;
import java.io.File;
import java.io.FileNotFoundException;
import java.net.URI;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Formatter;
import java.util.Scanner;

/**
 *
 * @author isaac
 */
public class Social_Network_Manager {

    public static Scanner sc = new Scanner(System.in);

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {

        if (args.length >= 3) {
            boolean orientedNetwork = false;
            String[][] infoNos = new String[Config.N_MAX_NOS][Config.N_CAMPOS_INFO];
            int nosLength = LeitorFicheiros.lerMatriz(args[args.length - 2], Config.N_CAMPOS_INFO, infoNos, Config.N_MAX_NOS);
            infoNos = adaptarMatrizNos(infoNos, nosLength);
            nosLength--;
           
            String[][] ramos = new String[Config.N_MAX_NOS][Config.N_CAMPOS_RELACOES];
            int ramosLength = LeitorFicheiros.lerMatriz(args[args.length - 1], Config.N_CAMPOS_RELACOES, ramos, Config.N_MAX_RAMOS);
            if (ramos[0][0].trim().equals("networkType:oriented")) {
                orientedNetwork = true;
            } else if (ramos[0][0].trim().equals("networkType:nonoriented")) {
                orientedNetwork = false;
            } else {
                System.out.println("O ficheiro não indica o tipo de network do grafo");
                ramosLength = 0;
            }
            ramos = adaptarMatrizRamos(ramos, ramosLength);
            ramosLength -= 2;
            if (nosLength > 0 && ramosLength > 0) {
                double[][] Matriz = criarMatriz(infoNos, ramos, ramosLength, nosLength, orientedNetwork);
                if (args[0].equals("-t")) {
                    Formatter output = criarEAbrirFicheiroTexto(args);
                    if (!orientedNetwork) {

                        outputInfoGrausNos(output, Matriz, infoNos);
                        output.format("Grau médio= %f.2%n%n", CalculosMatrizes.calcularGrauMedio(Matriz));
                        output.format("Densidade= %f.2%n%n", CalculosMatrizes.calcularDensidade(Matriz, calcNumRamos(ramos, ramosLength, infoNos, nosLength)));
                        output.format("Centralidade do vetor próprio: %f.2%n%n", CalculosMatrizes.calcCentralidadeVetorProprio(Matriz));

                        if (args[1].equals("-k")) {
                            if (Integer.parseInt(args[2]) > 0 && args.length >= 5) {
                                outputMatrizPotencia(output, Integer.parseInt(args[2]), Matriz);
                            } else {
                                output.format("A matriz de potências não pode ser criada pois o valor inserido não é válido.%n");
                            }
                        }
                        outputValoresProprios(output, Matriz);
                        outputVetoresProprios(output, Matriz);

                    } else if (orientedNetwork) {
                        outputGrausEntrada(output, Matriz, infoNos);
                        outputGrausSaida(output, Matriz, infoNos);
                        if (args.length >= 7) {
                            if ((args[1].equals("-k") && args[3].equals("-d")) || (args[1].equals("-d") && args[3].equals("-k"))) {
                                int nIteracoes;
                                double dampingFactor;
                                if ((args[1].equals("-k") && args[3].equals("-d"))) {
                                    nIteracoes = Integer.parseInt(args[2]);
                                    dampingFactor = Double.parseDouble(args[4]);
                                    outputPageRank(output, Matriz, dampingFactor, nIteracoes, infoNos);
                                } else if (args[1].equals("-d") && args[3].equals("-k")) {
                                    nIteracoes = Integer.parseInt(args[4]);
                                    dampingFactor = Double.parseDouble(args[2]);
                                    outputPageRank(output, Matriz, dampingFactor, nIteracoes, infoNos);
                                } else {
                                    System.out.println("Não é possível apresentar o page rank. Verifique os argumentos introduzidos");
                                }
                            }
                        }
                        String data = new SimpleDateFormat("MMdd").format(Calendar.getInstance().getTime());
                        if (data.equals("1225")) {
                            output.format("Feliz Natal!");
                        }
                        if (data.equals("1231")) {
                            output.format("Boas entradas!");
                        }
                        if (data.equals("0610")) {
                            output.format("Feliz dia de Portugal!");
                        }

                        System.out.println("Criação do ficheiro bem sucedida.");
                        output.close();
                    }
                } else if (args[0].equals("-n")) {
                    Formatter output = new Formatter(System.out);
                    if (orientedNetwork) {

                        int opcao = MenuOriented();
                        switch (opcao) {
                            case 1:
                                outputGrausEntrada(output, Matriz, infoNos);
                                break;
                            case 2:
                                outputGrausSaida(output, Matriz, infoNos);
                                break;
                            case 3:
                                output.format("Que método do PageRank pretende usar?%n");
                                output.format("1- Iterativo%n");
                                output.format("2- Vetor Próprio%n");
                                int opcaoPR;
                                do {
                                    System.out.println("Escolha a opção:");
                                    opcaoPR = sc.nextInt();
                                } while (opcaoPR > 2 || opcaoPR <= 0);

                                output.format("Insira o damping factor:%n");

                                double dampingFactor = sc.nextDouble();

                                if (dampingFactor > 0 && dampingFactor <= 1) {
                                    if (opcaoPR == 1) {
                                        output.format("Insira o número de iterações desejado");
                                        int nIteracoes = sc.nextInt();
                                        if (nIteracoes > 0) {
                                            outputPageRank(output, Matriz, dampingFactor, nIteracoes, infoNos);
                                        } else {
                                            System.out.println("Não é possível fazer esse número de iterações");
                                        }
                                    } else if (opcaoPR == 2) {
                                        outputPageRankMetodoVetor(output, Matriz, dampingFactor, infoNos);
                                    }
                                } else {
                                    System.out.println("O damping factor tem de estar entre 0 e 1%n");
                                }

                                break;

                        }
                    } else if (!orientedNetwork) {

                        int opcao = MenuNonOriented();
                        switch (opcao) {
                            case 1:
                                outputInfoGrausNos(output, Matriz, infoNos);
                                break;
                            case 2:
                                output.format("A centralidade do vetor próprio é: %.2f%n", CalculosMatrizes.calcCentralidadeVetorProprio(Matriz));
                                break;
                            case 3:
                                output.format("O grau médio da rede é %.2f%n", CalculosMatrizes.calcularGrauMedio(Matriz));
                                break;
                            case 4:
                                output.format("A densidade da rede é: %.2f%n", CalculosMatrizes.calcularDensidade(Matriz, calcNumRamos(ramos, ramosLength, infoNos, nosLength)));
                                break;
                            case 5:
                                output.format("Insira o grau da potência da matriz que quer calcular%n");
                                int grauPotencia = sc.nextInt();
                                if (grauPotencia > 0) {
                                    outputMatrizPotencia(output, grauPotencia, Matriz);
                                } else {
                                    System.out.println("O grau da potência tem de ser 1 ou maior.");
                                }
                                break;
                        }
                    }
                    abrirWebsite(encontrarWebsiteMaiorPageRank(output, Matriz, infoNos));

                } else {
                    System.out.println("Utilização do comando: [-t] [-k] [Grau potência] [nome do ficheiro rede nós] [nome ficheiro rede ramos]\n "
                            + "ou [-n] [nome do ficheiro rede nós] [nome ficheiro rede ramos]");
                }

            } else {
                System.out.println("Erro ao ler os ficheiros, verifique se os ficheiros existem e têm o formato correto.");

            }

        } else {
            System.out.println("Utilização do comando: [-t] [-k] [Grau potência] [nome do ficheiro rede nós] [nome ficheiro rede ramos]\n "
                    + "ou [-n] [nome do ficheiro rede nós] [nome ficheiro rede ramos]");
        }
    }

    private static void outputVetoresProprios(Formatter output, double[][] Matriz) {
        output.format("Os vetores próprios são: %n");
        double vecProprios[][] = CalculosMatrizes.calcularVetoresProprios(Matriz);
        for (int i = 0; i < vecProprios.length; i++) {
            for (int j = 0; j < vecProprios[i].length; j++) {
                if (vecProprios[i][j] > -0.001 && vecProprios[i][j] < 0.001) {
                    vecProprios[i][j] = 0;
                }

                output.format("%5.2f ", vecProprios[i][j]);
            }
            output.format("%n");

        }
    }

    public static int MenuNonOriented() {
        System.out.println("Escolha uma opção");
        System.out.println("1- Grau de um nó ");
        System.out.println("2- Centralidade do vetor próprio");
        System.out.println("3- Grau médio da rede");
        System.out.println("4- Densidade da rede");
        System.out.println("5- Potências da Matriz de Adjacências");
        System.out.println("0-Cancelar");

        int opcao;
        do {
            System.out.println("Escolha a opção:");

            opcao = sc.nextInt();
        } while (opcao > 5 || opcao < 0);

        sc.nextLine();
        return opcao;
    }

    public static int MenuOriented() {
        System.out.println("Escolha uma opção");
        System.out.println("1- Graus de entrada dos nós ");
        System.out.println("2- Graus de saída dos nós");
        System.out.println("3- PageRank");
        System.out.println("0-Cancelar");

        int opcao;
        do {
            System.out.println("Escolha a opção:");

            opcao = sc.nextInt();
        } while (opcao > 3 || opcao < 0);

        sc.nextLine();
        return opcao;
    }

    private static void outputValoresProprios(Formatter output, double[][] Matriz) {
        output.format("Os valores próprios são: ");
        double valProprios[] = CalculosMatrizes.calcularValoresProprios(Matriz);
        double valPropriosSemRepetidos[] = new double[valProprios.length];
        int nValProprios = CalculosMatrizes.eliminarValoresPropriosRepetidos(valProprios, valPropriosSemRepetidos);
        for (int i = 0; i < nValProprios; i++) {
            output.format("%5.2f ", valPropriosSemRepetidos[i]);
        }
        output.format("%n%n");
    }

    private static void outputMatrizPotencia(Formatter output, int grau, double[][] Matriz) throws NumberFormatException {
        output.format("A potência da matriz de adjacências de grau %s é:%n", grau);
        double[][] matrizPotencia = CalculosMatrizes.potenciaMatrizAdjacencias(Matriz, grau);
        for (int i = 0; i < matrizPotencia.length; i++) {
            for (int j = 0; j < matrizPotencia[i].length; j++) {
                output.format("%7.2f ", matrizPotencia[i][j]);
            }
            output.format("%n");
        }
        output.format("%n");
    }

    private static void outputInfoGrausNos(Formatter output, double[][] Matriz, String[][] infoNos) {
        output.format("%16s%n", "Graus dos nós:");
        output.format("%10s%10s%n", "ID do nó", "Grau");
        for (int i = 0; i < Matriz.length; i++) {
            output.format("%10s%10d%n", infoNos[i][Config.POSICAO_ID_NOS], CalculosMatrizes.calcularGrauNo(Matriz, i));
        }
        output.format("%n");
    }

    private static void outputGrausEntrada(Formatter output, double[][] Matriz, String[][] infoNos) {
        output.format("%16s%n", "Graus de entrada:");
        output.format("%10s%10s%n", "ID do nó", "Grau");
        for (int i = 0; i < Matriz[0].length; i++) {
            output.format("%10s%10d%n", infoNos[i][Config.POSICAO_ID_NOS], CalculosMatrizes.calcularGrauEntrada(Matriz, i));
        }
        output.format("%n");
    }

    private static void outputGrausSaida(Formatter output, double[][] Matriz, String[][] infoNos) {
        output.format("%16s%n", "Graus de saída:");
        output.format("%10s%10s%n", "ID do nó", "Grau");
        for (int i = 0; i < Matriz.length; i++) {
            output.format("%10s%10d%n", infoNos[i][Config.POSICAO_ID_NOS], CalculosMatrizes.calcularGrauSaida(Matriz, i));
        }
        output.format("%n");
    }

    private static void outputPageRank(Formatter output, double[][] Matriz, double dampingFactor, int nIteracoes, String[][] infoNos) {
        double[][] pageRank = CalculosMatrizes.calcPageRank(Matriz, dampingFactor, nIteracoes);
        output.format("%16s%n", "PageRanks:");
        output.format("%10s%10s%n", "ID do nó", "Rank");
        for (int i = 0; i < pageRank.length; i++) {
            output.format("%10s%10f%n", infoNos[i][Config.POSICAO_ID_NOS], pageRank[i][Config.POS_PAGERANK]);
        }
    }

    private static void outputPageRankMetodoVetor(Formatter output, double[][] Matriz, double dampingFactor, String[][] infoNos) {
        double[][] pageRank = CalculosMatrizes.calcPageRankMetodoVetor(Matriz, dampingFactor);
        output.format("%16s%n", "PageRanks:");
        output.format("%10s%10s%n", "ID do nó", "Rank");
        for (int i = 0; i < pageRank.length; i++) {
            output.format("%10s%10d%n", infoNos[i][Config.POSICAO_ID_NOS], pageRank[i][Config.LENGTH_VETOR_PAGERANK]);
        }
    }

    private static Formatter criarEAbrirFicheiroTexto(String[] args) throws FileNotFoundException {
        String data = new SimpleDateFormat("yyyyMMdd").format(Calendar.getInstance().getTime());
        Formatter output = new Formatter(new File(args[args.length - 1].substring(0, args[args.length - 1].lastIndexOf('_') + 1)) + data + ".txt");
        return output;
    }

    /**
     * Cria a matriz adjunta utilizando a informação dos ficheiros inseridos
     *
     * @param infoNos
     * @param ramos
     * @param ramosLength
     * @param nosLength
     * @return
     */
    public static double[][] criarMatriz(String[][] infoNos, String[][] ramos, int ramosLength, int nosLength, boolean orientedNetwork) {
        int pos1, pos2;

        double[][] Matriz = new double[nosLength][nosLength];

        for (int i = 0; i < Matriz.length; i++) {
            for (int j = 0; j < Matriz.length; j++) {
                Matriz[i][j] = 0;
            }

        }
        for (int i = 0; i < ramosLength; i++) {
            pos1 = Utilitarios.procurarString(infoNos, ramos[i][Config.POSICAO_ID_FROM], nosLength);
            pos2 = Utilitarios.procurarString(infoNos, ramos[i][Config.POSICAO_ID_TO], nosLength);
            if (pos1 != -1 && pos2 != -1 && pos1 != pos2) {
                Matriz[pos1][pos2] = 1;
                if (!orientedNetwork) {
                    Matriz[pos2][pos1] = 1;
                }
            }

        }
        return Matriz;
    }

    /**
     * Calcula o número de ramos existente utilizando contando os dados válidos
     * no ficheiro de informação de ramos
     *
     * @param ramos
     * @param ramosLength
     * @param infoNos
     * @param nosLength
     * @return
     */
    public static int calcNumRamos(String[][] ramos, int ramosLength, String[][] infoNos, int nosLength) {
        int nRamos = 0;
        for (int i = 0; i < ramosLength; i++) {

            int pos1 = Utilitarios.procurarString(infoNos, ramos[i][Config.POSICAO_ID_FROM], nosLength);
            int pos2 = Utilitarios.procurarString(infoNos, ramos[i][Config.POSICAO_ID_TO], nosLength);
            if (pos1 != pos2) {
                nRamos++;
            }
        }
        return nRamos;
    }

    public static String[][] adaptarMatrizNos(String[][] infoNos, int nosLength) {

        String[][] newMatrizNos = new String[Config.N_MAX_NOS][Config.N_CAMPOS_INFO];
        for (int i = 1; i < nosLength; i++) {
            newMatrizNos[i - 1] = infoNos[i];
        }

        return newMatrizNos;
    }

    public static String[][] adaptarMatrizRamos(String[][] ramos, int nosLength) {

        String[][] newMatrizNos = new String[Config.N_MAX_NOS][Config.N_CAMPOS_INFO];
        for (int i = 2; i < nosLength; i++) {
            newMatrizNos[i - 2] = ramos[i];
        }

        return newMatrizNos;
    }

    public static void abrirWebsite(String nomeWebSite) {
        try {
            Desktop desktop = java.awt.Desktop.getDesktop();
            
            URI oURL = new URI(nomeWebSite.trim());
            desktop.browse(oURL);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String encontrarWebsiteMaiorPageRank(Formatter output, double[][] Matriz, String[][] infoNos) {
        double[][] pageRank = CalculosMatrizes.calcPageRankMetodoVetor(Matriz, 1);
        double maiorRank = 0;
        int posMaiorRank = -1;
        for (int i = 0; i < pageRank.length; i++) {
            System.out.println(pageRank[i][0]);
            if (pageRank[i][0] > maiorRank) {
                maiorRank = pageRank[i][0];
                posMaiorRank = i;
            }
        }
        return infoNos[posMaiorRank][Config.POSICAO_WEBSITE];
    }
}
