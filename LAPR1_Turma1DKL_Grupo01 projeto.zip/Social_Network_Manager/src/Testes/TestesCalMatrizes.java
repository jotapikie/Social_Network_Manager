/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Testes;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import social_network_manager.CalculosMatrizes;
import social_network_manager.Social_Network_Manager;

/**
 *
 * @author isaac
 */
public class TestesCalMatrizes {

    public static void main(String[] args) {

        double[][] matrizTestes1 = {{1, 0, 1}, {1, 1, 1}, {1, 1, 0}};
        double[][] matrizTestes2 = {{0, 1, 0, 1}, {1, 0, 1, 0}, {0, 1, 0, 0}, {1, 0, 0, 0}};

        System.out.println("Metodo maxValProprio funciona= " + testeCalcMaxValProprio(matrizTestes1, 2.25));

        System.out.println("Metodo calcularGrauSaida funciona= " + testeCalcularGrauSaida(matrizTestes1, 1, 3));

        System.out.println("Metodo calcularGrauEntrada funciona= " + testeCalcularGrauEntrada(matrizTestes1, 2, 2));

        System.out.println("Metodo calcularGrauNo funciona= " + testeCalcularGrauNo(matrizTestes1, 2, 2));

        System.out.println("Metodo CalcDensidade funciona= " + testeCalcDensidade(matrizTestes2, 6, 0.5f));

        System.out.println("Metodo CalcularGrauMedio funciona= " + testeCalcularGrauMedio(matrizTestes2, 1.5f));

        double[] valoresPropriosEsperados = {2.25, 0.55, -0.80};
        System.out.println("Metodo CalcularValoresProprios funciona= " + testeCalcularValoresProprios(matrizTestes1, valoresPropriosEsperados));
        
        
        double[][] matTestMult1={{1.0},{0},{1.0},{1.0}};
        double[][] matTestMult2={{1.0,1.0,0,0},{0,1,0,1},{0,1,0,1.0},{1.0,1,0,1}};
        double[][] matResultadoEsperado={{1},{1},{1},{2}};
        System.out.println("Metodo MultiplicarMatrizes funciona= " + testeMultiplicarMatrizes(matTestMult2, matTestMult1,matResultadoEsperado));
        
        
    }

    public static boolean testeCalcMaxValProprio(double[][] matrix, double maxValProprioEsperado) {
        double maxEigenvalue = CalculosMatrizes.calcMaxValProprio(matrix);

        if (maxValProprioEsperado == (double) Math.round(maxEigenvalue * 100) / 100) {
            return true;
        } else {
            return false;
        }

    }

    public static boolean testeCalcularGrauSaida(double[][] ramos, int posicaoID, int resultadoEsperado) {
        int grauSaida = CalculosMatrizes.calcularGrauSaida(ramos, posicaoID);
        if (grauSaida == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean testeCalcularGrauEntrada(double[][] ramos, int posicaoID, int resultadoEsperado) {
        int grauSaida = CalculosMatrizes.calcularGrauEntrada(ramos, posicaoID);
        if (grauSaida == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean testeCalcularGrauNo(double[][] ramos, int posicaoID, int resultadoEsperado) {
        int grau = CalculosMatrizes.calcularGrauNo(ramos, posicaoID);
        if (grau == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean testeCalcDensidade(double[][] Matriz, int nrRamos, float resultadoEsperado) {
        float densidade = CalculosMatrizes.calcularDensidade(Matriz, nrRamos);
        if (densidade == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean testeCalcularGrauMedio(double[][] Matriz, float resultadoEsperado) {
        float grauMedio = CalculosMatrizes.calcularGrauMedio(Matriz);
        if (grauMedio == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }

    public static boolean testeCalcularValoresProprios(double[][] Matriz, double[] resultadoEsperado) {
        double[] valProprios = CalculosMatrizes.calcularValoresProprios(Matriz);
        double[] valPropriosSemRepetidos = new double[valProprios.length];
        int nValoresProprios = CalculosMatrizes.eliminarValoresPropriosRepetidos(valProprios, valPropriosSemRepetidos);
        for (int i = 0; i < nValoresProprios; i++) {
            valPropriosSemRepetidos[i] = (double) Math.round(valPropriosSemRepetidos[i] * 100) / 100;
        }
        for (int i = 0; i < nValoresProprios - 1; i++) {

            if (valPropriosSemRepetidos[i] < valPropriosSemRepetidos[i + 1]) {
                double temp = valPropriosSemRepetidos[i];
                valPropriosSemRepetidos[i] = valPropriosSemRepetidos[i + 1];
                valPropriosSemRepetidos[i + 1] = temp;
            }
        }

        for (int i = 0; i < nValoresProprios; i++) {
            if (valPropriosSemRepetidos[i] != resultadoEsperado[i]) {
                System.out.println(valPropriosSemRepetidos[i]);
                return false;

            }

        }
        return true;
    }

    public static boolean testeCalcularVetoresProprios(double[][] Matriz, double[][] resultadoEsperado) {
        double[][] vecProprios = CalculosMatrizes.calcularVetoresProprios(Matriz);

        for (int i = 0; i < vecProprios.length; i++) {
            for (int j = 0; j < vecProprios[i].length; j++) {
                if (vecProprios[i][j] != resultadoEsperado[i][j]) {
                    return false;
                }

            }
        }
        return true;
    }

    public static boolean testePotenciaMatrizAdjacencias(double[][] Matriz, double[][] resultadoEsperado) {
        double[][] matrizPotencia = CalculosMatrizes.potenciaMatrizAdjacencias(Matriz, 3);

        for (int i = 0; i < matrizPotencia.length; i++) {
            for (int j = 0; j < matrizPotencia[i].length; j++) {
                if (matrizPotencia[i][j] != resultadoEsperado[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean testeMultiplicarMatrizes(double[][] Matriz1, double[][] Matriz2, double[][] resultadoEsperado) {
        double[][] multMatriz = CalculosMatrizes.multiplicarMatrizes(Matriz1, Matriz2);

        for (int i = 0; i < multMatriz.length; i++) {
            for (int j = 0; j < multMatriz[i].length; j++) {
                if (multMatriz[i][j] != resultadoEsperado[i][j]) {
                    return false;
                }
            }
        }
        return true;
    }

    public static boolean testeCalcCentralidadeVetorProprio(double[][] Matriz, double resultadoEsperado) {
        double centVetorP = CalculosMatrizes.calcCentralidadeVetorProprio(Matriz);
        if (centVetorP == resultadoEsperado) {
            return true;
        } else {
            return false;
        }
    }
}
